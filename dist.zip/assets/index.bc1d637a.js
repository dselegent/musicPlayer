import{d as c,b as e,c as o}from"./index.4279e7a9.js";const s={class:"localMusic"},t=c({name:"LocalMusic"}),r=c({...t,setup(a){return(n,_)=>(e(),o("div",s," localMusic "))}});export{r as default};
