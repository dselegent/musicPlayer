import{_ as e,b as n,c as o}from"./index.4279e7a9.js";const t={name:"SingerMv"};function c(r,s,_,a,p,i){return n(),o("div",null,"MV")}const u=e(t,[["render",c]]);export{u as default};
