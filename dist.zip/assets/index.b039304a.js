import{r as a}from"./index.4279e7a9.js";const e=a("popularMusic"),r=e;export{r as a};
